(function () {
  "use strict";

  const APP_ID = "deal-alliance-wa-exporter";
  const STATE_KEY = "__dealAllianceWaExporter";
  const TRIAL_KEY = "__dealAllianceWaExporterTrial";
  const TRIAL_DAYS = 7;
  const DAY_MS = 24 * 60 * 60 * 1000;
  const PHONE_RE = /(?:\+|00)?\d[\d\s().-]{7,}\d/g;
  const INTERNAL_PAIR_NOTE = "補電話：頁面內部聯絡人狀態配對";
  const INTERNAL_BULK_NOTE = "來源：WhatsApp Web 已載入內部聯絡人/聊天狀態";
  const DETAIL_PAIR_NOTE = "補電話：逐筆打開聊天/資訊頁取得";

  function normalizePhone(value) {
    if (!value) return "";
    let text = String(value).replace(/[^\d+]/g, "");
    if (text.startsWith("00") && text.length > 4) text = `+${text.slice(2)}`;
    if (!text.startsWith("+")) text = `+${text}`;
    const digits = text.replace(/\D/g, "");
    if (!isPlausiblePhoneDigits(digits)) return "";
    return `+${digits}`;
  }

  function isPlausiblePhoneDigits(digits) {
    if (!digits || digits.length < 8 || digits.length > 15) return false;
    if (digits.startsWith("0")) return false;
    if (digits.startsWith("100")) return false;
    if (digits.startsWith("1")) {
      if (digits.length !== 11) return false;
      if (!/^1[2-9]\d{2}[2-9]\d{6}$/.test(digits)) return false;
    }
    return true;
  }

  function extractPhones(value) {
    const matches = String(value || "").match(PHONE_RE) || [];
    return Array.from(new Set(matches.map(normalizePhone).filter(Boolean)));
  }

  function cleanText(value) {
    return String(value || "")
      .replace(/\u200e|\u200f/g, "")
      .replace(/\s+/g, " ")
      .trim();
  }

  function unique(values) {
    return Array.from(new Set(values.map(cleanText).filter(Boolean)));
  }

  function isLikelySystemOrMessageText(value) {
    const text = cleanText(value);
    if (!text) return true;
    if (extractPhones(text).length) return true;
    if (text.length > 48) return true;
    if (/Meta\s*提供|安全服務|點擊了解更多|此商家目前使用|messages are end-to-end encrypted|end-to-end encrypted/i.test(text)) return true;
    if (/[?？]$/.test(text)) return true;
    if (/(最近|現在|今天|明天|昨天|請問|可以|想問|想了解|報名|資料|課程|台灣|在嗎|有在|嗎)$/i.test(text)) return true;
    if (/^(ok|okay|3q|no q|照片|圖片|影片|貼圖|文件|語音訊息|photo|photos|image|video|sticker|document)$/i.test(text)) return true;
    if (!/[\p{L}\p{N}]/u.test(text)) return true;
    if (/^(online|typing|已讀|未讀|delivered|sent|上午|下午|昨天|today|yesterday)$/i.test(text)) return true;
    return false;
  }

  function trustedName(value) {
    const text = cleanText(value);
    if (!text || isLikelySystemOrMessageText(text)) return "";
    if (/^\+?\d[\d\s().-]{7,}\d$/.test(text)) return "";
    return text;
  }

  function nameKey(value) {
    return cleanText(value).toLowerCase();
  }

  function looseNameKey(value) {
    return cleanText(value)
      .toLowerCase()
      .replace(/[\u200e\u200f]/g, "")
      .replace(/[^\p{L}\p{N}]+/gu, " ")
      .replace(/\s+/g, " ")
      .trim();
  }

  function nameTokens(value) {
    return looseNameKey(value)
      .split(" ")
      .map((token) => token.trim())
      .filter((token) => token.length >= 2 && !/^\d+$/.test(token));
  }

  function namesProbablyMatch(a, b) {
    const left = looseNameKey(a);
    const right = looseNameKey(b);
    if (!left || !right) return false;
    if (left === right) return true;
    if ((left.length >= 5 && right.includes(left)) || (right.length >= 5 && left.includes(right))) return true;
    const leftTokens = new Set(nameTokens(left));
    const rightTokens = new Set(nameTokens(right));
    const overlap = Array.from(leftTokens).filter((token) => rightTokens.has(token));
    if (overlap.length >= 2) return true;
    return overlap.some((token) => token.length >= 5);
  }

  function phoneFromWid(value) {
    const text = cleanText(value && value._serialized ? value._serialized : value);
    const server = cleanText(value && value.server ? value.server : "");
    if (server && server !== "c.us") return "";
    if (!text || /@(g\.us|lid)\b/i.test(text)) return "";
    if (/@/.test(text) && !/@c\.us\b/i.test(text)) return "";
    const user = value && value.user ? value.user : "";
    const candidates = [user, text.split("@")[0], text];
    for (const candidate of candidates) {
      const phone = normalizePhone(candidate);
      if (phone) return phone;
    }
    return "";
  }

  function safeCall(fn) {
    try {
      return typeof fn === "function" ? fn() : null;
    } catch (_) {
      return null;
    }
  }

  async function safeAsyncCall(fn) {
    try {
      return typeof fn === "function" ? await fn() : null;
    } catch (_) {
      return null;
    }
  }

  function safeStorageGet(key) {
    try {
      return localStorage.getItem(key);
    } catch (_) {
      return null;
    }
  }

  function safeStorageSet(key, value) {
    try {
      localStorage.setItem(key, value);
    } catch (_) {
      return false;
    }
    return true;
  }

  function trialInfo() {
    const now = Date.now();
    let data = null;
    const raw = safeStorageGet(TRIAL_KEY);
    if (raw) {
      try {
        data = JSON.parse(raw);
      } catch (_) {
        data = null;
      }
    }
    if (!data || !Number(data.startedAt) || !Number(data.expiresAt)) {
      data = {
        startedAt: now,
        expiresAt: now + TRIAL_DAYS * DAY_MS,
      };
      safeStorageSet(TRIAL_KEY, JSON.stringify(data));
    }
    const remainingMs = data.expiresAt - now;
    return {
      startedAt: data.startedAt,
      expiresAt: data.expiresAt,
      expired: remainingMs <= 0,
      remainingDays: Math.max(0, Math.ceil(remainingMs / DAY_MS)),
    };
  }

  function isTrialExpired() {
    return trialInfo().expired;
  }

  function trialMessage() {
    const info = trialInfo();
    const expiryDate = new Date(info.expiresAt).toLocaleDateString("zh-TW");
    if (info.expired) return `七天試用已到期。請聯絡成交聯盟開通正式版。`;
    return `七天試用中：剩 ${info.remainingDays} 天，到期日 ${expiryDate}。`;
  }

  function collectionItems(collection) {
    if (!collection) return [];
    if (Array.isArray(collection)) return collection;
    if (collection instanceof Map) return Array.from(collection.values());
    const arrays = [
      collection.models,
      collection._models,
      collection.__x_models,
      collection.contacts,
      collection.chats,
    ].filter(Boolean);
    const fromFunctions = [
      safeCall(() => collection.getModelsArray()),
      safeCall(() => collection.toArray()),
    ].filter(Boolean);
    const values = arrays.concat(fromFunctions).flatMap((item) => {
      if (Array.isArray(item)) return item;
      if (item instanceof Map) return Array.from(item.values());
      if (item && typeof item === "object") return Object.values(item);
      return [];
    });
    if (!values.length && typeof collection === "object") return Object.values(collection);
    return values;
  }

  function contactNamesFromObject(item) {
    if (!item || typeof item !== "object") return [];
    return unique([
      item.formattedName,
      item.name,
      item.pushname,
      item.shortName,
      item.verifiedName,
      item.displayName,
      item.notifyName,
      item.mentionName,
      item.fullName,
      item.title,
      item.profileName,
      item.username,
      item.contact && item.contact.formattedName,
      item.contact && item.contact.name,
      item.contact && item.contact.pushname,
      item.contact && item.contact.displayName,
      item.__x_contact && item.__x_contact.formattedName,
      item.__x_contact && item.__x_contact.name,
      item.__x_contact && item.__x_contact.pushname,
      item.__x_contact && item.__x_contact.displayName,
    ].map(trustedName)).filter(Boolean);
  }

  function isSavedAddressBookContact(item) {
    if (!item || typeof item !== "object") return false;
    return [
      item.isMyContact,
      item.isAddressBookContact,
      item.isAddressbookContact,
      item.__x_isMyContact,
      item.__x_isAddressBookContact,
      item.contact && item.contact.isMyContact,
      item.contact && item.contact.isAddressBookContact,
      item.__x_contact && item.__x_contact.isMyContact,
      item.__x_contact && item.__x_contact.isAddressBookContact,
    ].some((value) => value === true);
  }

  function contactRecordFromObject(item) {
    if (!item || typeof item !== "object") return null;
    const id = item.id || item.__x_id || item._id || item.contactId || (item.contact && item.contact.id) || (item.__x_contact && item.__x_contact.id);
    const phone = phoneFromWid(id) ||
      phoneFromWid(item.wid) ||
      phoneFromWid(item.jid) ||
      phoneFromWid(item.phoneNumber) ||
      phoneFromWid(item.phone) ||
      phoneFromWid(item.user) ||
      phoneFromWid(item.pn);
    const names = contactNamesFromObject(item);
    if (!phone) return null;
    return { phone, names, saved: isSavedAddressBookContact(item) };
  }

  function outputRecordFromInternalContact(record, source) {
    if (record.saved) return null;
    const name = (record.names || []).find((item) => trustedName(item)) || "";
    return {
      "姓名": name,
      "手機": record.phone || "",
      "公司": "",
      "職稱": "",
      "備註": INTERNAL_BULK_NOTE,
      "群組 / 標籤": source || "WhatsApp",
      "來源": source || "WhatsApp 內部狀態",
      "電話狀態": record.phone ? "已由內部狀態配對" : "缺電話",
      "最後互動": "",
      "最後訊息摘要": "",
    };
  }

  function webpackRequire() {
    if (window.__dealAllianceWaWebpackRequire) return window.__dealAllianceWaWebpackRequire;
    const chunkKey = Object.keys(window).find((key) => /^webpackChunk/.test(key) && Array.isArray(window[key]));
    const chunk = chunkKey && window[chunkKey];
    if (!chunk || typeof chunk.push !== "function") return null;
    let found = null;
    try {
      chunk.push([[`deal-alliance-${Date.now()}`], {}, (req) => {
        found = req;
      }]);
    } catch (_) {
      found = null;
    }
    if (found && found.c) window.__dealAllianceWaWebpackRequire = found;
    return found && found.c ? found : null;
  }

  function discoverWebpackSources() {
    const req = webpackRequire();
    if (!req || !req.c) return [];
    const sources = [];
    const seen = new WeakSet();
    const startedAt = Date.now();
    const overBudget = () => Date.now() - startedAt > 900 || sources.length > 60;
    const add = (value, depth) => {
      if (!value || typeof value !== "object" || seen.has(value) || depth > 2 || overBudget()) return;
      seen.add(value);
      const directRecord = contactRecordFromObject(value);
      if (directRecord) {
        sources.push([value]);
        return;
      }
      const keys = Object.keys(value).slice(0, 80);
      const looksRelevant = keys.some((key) => /contact|chat|participant|member|models|wid|user/i.test(key));
      if (!looksRelevant) return;
      const items = collectionItems(value);
      if (items.some((item) => contactRecordFromObject(item))) {
        sources.push(value);
        return;
      }
      keys.forEach((key) => add(value[key], depth + 1));
    };
    for (const module of Object.values(req.c)) {
      if (overBudget()) break;
      if (!module || !module.exports) continue;
      add(module.exports, 0);
      add(module.exports.default, 0);
    }
    return sources;
  }

  function internalSourceCollections() {
    const sources = [];
    if (window.Store) {
      sources.push(window.Store.Contact, window.Store.Chat);
    }
    if (window.WPP && window.WPP.whatsapp) {
      sources.push(
        window.WPP.whatsapp.ContactStore,
        window.WPP.whatsapp.ChatStore
      );
    }
    sources.push(...discoverWebpackSources());
    return sources.filter(Boolean);
  }

  function collectInternalContacts() {
    const records = [];
    const seen = new Set();
    const add = (item) => {
      const record = contactRecordFromObject(item);
      if (!record) return;
      const key = `${record.phone}|${record.names.join("|")}`;
      if (seen.has(key)) return;
      seen.add(key);
      records.push(record);
    };

    for (const source of internalSourceCollections()) {
      for (const item of collectionItems(source)) {
        add(item);
        if (item && typeof item === "object") {
          add(item.contact);
          add(item.__x_contact);
          const participants = item.groupMetadata && item.groupMetadata.participants;
          for (const participant of collectionItems(participants)) {
            add(participant);
            add(participant && participant.contact);
          }
        }
      }
    }
    return records;
  }

  async function collectWppApiContacts() {
    const records = [];
    const seen = new Set();
    const add = (item) => {
      const record = contactRecordFromObject(item);
      if (!record || seen.has(record.phone)) return;
      seen.add(record.phone);
      records.push(record);
    };
    const wpp = window.WPP || {};
    const contactApi = wpp.contact || {};
    const chatApi = wpp.chat || {};
    const groupApi = wpp.group || {};
    const contacts = await safeAsyncCall(() => contactApi.getAllContacts());
    const chats = await safeAsyncCall(() => chatApi.getAllChats ? chatApi.getAllChats() : null);
    const groups = await safeAsyncCall(() => groupApi.getAllGroups ? groupApi.getAllGroups() : null);
    [contacts, chats, groups].forEach((collection) => {
      for (const item of collectionItems(collection)) {
        add(item);
        if (item && typeof item === "object") {
          add(item.contact);
          add(item.__x_contact);
          for (const participant of collectionItems(item.participants || item.groupMetadata && item.groupMetadata.participants)) {
            add(participant);
            add(participant && participant.contact);
          }
        }
      }
    });
    return records;
  }

  async function bulkCaptureInternalContacts() {
    const appState = state();
    const records = [];
    const seen = new Set();
    const addRecord = (record) => {
      if (!record || !record.phone || seen.has(record.phone)) return;
      seen.add(record.phone);
      records.push(record);
    };
    collectInternalContacts().forEach(addRecord);
    (await collectWppApiContacts()).forEach(addRecord);
    let added = 0;
    for (const record of records) {
      const outputRecord = outputRecordFromInternalContact(record, "WhatsApp 內部狀態");
      if (outputRecord && upsertRecord(outputRecord)) added += 1;
    }
    appState.internalIndex = null;
    appState.internalIndexAt = 0;
    return { added, total: records.length };
  }

  function internalContactIndex() {
    const appState = state();
    if (appState.internalIndex && Date.now() - appState.internalIndexAt < 30 * 1000) {
      return appState.internalIndex;
    }
    const byPhone = new Map();
    const byName = new Map();
    for (const record of collectInternalContacts()) {
      byPhone.set(record.phone, record);
      for (const name of record.names) {
        const key = nameKey(name);
        if (!key) continue;
        if (!byName.has(key)) byName.set(key, []);
        byName.get(key).push(record);
      }
    }
    appState.internalIndex = { byPhone, byName };
    appState.internalIndexAt = Date.now();
    return appState.internalIndex;
  }

  function internalMatch(record) {
    const index = internalContactIndex();
    if (record["手機"] && index.byPhone.has(record["手機"])) return index.byPhone.get(record["手機"]);
    const key = nameKey(record["姓名"]);
    const matches = key ? (index.byName.get(key) || []) : [];
    const phones = Array.from(new Set(matches.map((item) => item.phone).filter(Boolean)));
    if (phones.length === 1) return matches.find((item) => item.phone === phones[0]);
    const fuzzyMatches = [];
    index.byPhone.forEach((item) => {
      if (item.names.some((name) => namesProbablyMatch(record["姓名"], name))) fuzzyMatches.push(item);
    });
    const fuzzyPhones = Array.from(new Set(fuzzyMatches.map((item) => item.phone).filter(Boolean)));
    if (fuzzyPhones.length === 1) return fuzzyMatches.find((item) => item.phone === fuzzyPhones[0]);
    return null;
  }

  function enrichRecordFromInternalState(record) {
    if (!record || record["手機"]) return record;
    const match = internalMatch(record);
    if (match && match.saved) {
      record["已在手機通訊錄"] = true;
      return record;
    }
    if (!match || !match.phone) return record;
    record["手機"] = match.phone;
    record["電話狀態"] = "已由內部狀態配對";
    record["備註"] = [record["備註"], INTERNAL_PAIR_NOTE].filter(Boolean).join("；");
    return record;
  }

  function isKnownSavedContact(record) {
    if (!record) return false;
    const match = internalMatch(record);
    return Boolean(match && match.saved);
  }

  function findRows() {
    const selectors = [
      "[role='listitem']",
      "[role='row']",
      "[data-testid*='cell']",
      "[data-testid*='chat-list'] [role='listitem']",
    ];
    const found = new Set();
    for (const selector of selectors) {
      document.querySelectorAll(selector).forEach((node) => {
        if (!(node instanceof HTMLElement)) return;
        const text = cleanText(node.innerText || node.getAttribute("aria-label") || "");
        if (text.length < 2 || text.length > 900) return;
        const rect = node.getBoundingClientRect();
        if (rect.width < 80 || rect.height < 16) return;
        if (rect.height > 160) return;
        if (node.querySelectorAll("[role='listitem'], [role='row']").length > 1) return;
        found.add(node);
      });
    }
    return Array.from(found);
  }

  function titleCandidates(row) {
    const values = [];
    row.querySelectorAll("[title], [aria-label]").forEach((node) => {
      const title = cleanText(node.getAttribute("title") || node.getAttribute("aria-label") || "");
      if (title && title.length <= 120) values.push(title);
    });
    return values;
  }

  function nameFromRow(row, phones) {
    const titles = titleCandidates(row).map(trustedName).filter(Boolean);
    if (titles.length) return titles[0];
    const lines = String(row.innerText || "")
      .split(/\n+/)
      .map(cleanText)
      .filter(Boolean);
    const ignore = /^(online|typing|yesterday|today|上午|下午|\d{1,2}:\d{2}|週|星期|已讀|未讀|sent|delivered)$/i;
    for (const line of lines) {
      if (ignore.test(line)) continue;
      if (phones.includes(normalizePhone(line))) continue;
      if (extractPhones(line).length && line.replace(/[^\d]/g, "").length > 5) continue;
      const name = trustedName(line);
      if (name) return name;
    }
    return "";
  }

  function lastInfoFromRow(row) {
    const lines = String(row.innerText || "")
      .split(/\n+/)
      .map(cleanText)
      .filter(Boolean);
    const time = lines.find((line) =>
      /^(\d{1,2}:\d{2}|上午\s*\d{1,2}:\d{2}|下午\s*\d{1,2}:\d{2}|昨天|yesterday|today|\d{1,2}\/\d{1,2}\/\d{2,4})$/i.test(line)
    );
    const message = lines
      .filter((line) => line !== time)
      .slice(-1)[0] || "";
    return { time: time || "", message: message.slice(0, 160) };
  }

  function detectContext() {
    const text = cleanText(document.body.innerText || "");
    if (/group info|群組資訊|members|成員/i.test(text)) return "群組成員頁";
    if (/new chat|新聊天|contacts|聯絡人/i.test(text)) return "聯絡人列表";
    return "聊天列表";
  }

  function recordFromRow(row) {
    const text = cleanText(row.innerText || row.getAttribute("aria-label") || "");
    const titleText = titleCandidates(row).join(" ");
    const phones = Array.from(new Set(extractPhones(`${titleText} ${text}`)));
    const name = nameFromRow(row, phones);
    const info = lastInfoFromRow(row);
    if (!name && /Meta\s*提供|安全服務|點擊了解更多|此商家目前使用/i.test(`${titleText} ${text}`)) return null;
    if (!name && !phones.length) return null;
    const source = detectContext();
    return {
      "姓名": name || "",
      "手機": phones[0] || "",
      "公司": "",
      "職稱": "",
      "備註": [source, info.message && `最後訊息：${info.message}`].filter(Boolean).join("；"),
      "群組 / 標籤": "WhatsApp",
      "來源": source,
      "電話狀態": phones[0] ? "已抓到電話" : "缺電話",
      "最後互動": info.time,
      "最後訊息摘要": info.message,
    };
  }

  function nameFromPhoneLine(text, phone) {
    const normalized = normalizePhone(phone);
    let line = cleanText(text)
      .replace(/[\u200e\u200f]/g, "")
      .replace(/^[~\-–—\s]+/, "");
    const rawPhone = (String(text).match(PHONE_RE) || [phone])[0];
    const phoneAt = line.indexOf(rawPhone);
    line = phoneAt > 0
      ? cleanText(line.slice(0, phoneAt))
      : cleanText(line.replace(rawPhone, "").replace(normalized, ""));
    line = line
      .replace(/\b(?:上午|下午)?\s*\d{1,2}:\d{2}\b/g, "")
      .replace(/\b\d{4}[年/-]\d{1,2}[月/-]\d{1,2}日?\b/g, "")
      .replace(/[:：]+$/g, "")
      .replace(/^[~\-–—\s]+|[~\-–—\s]+$/g, "");
    line = trustedName(line);
    if (!line || extractPhones(line).length) return "";
    if (line.length > 80) return "";
    if (/^(online|typing|已讀|未讀|delivered|sent)$/i.test(line)) return "";
    return line;
  }

  function messageContactRecords() {
    const records = [];
    const seen = new Set();
    const selectors = [
      "[data-pre-plain-text]",
      "[role='application'] [role='row']",
      "[role='application'] [data-testid*='msg']",
      "main [data-pre-plain-text]",
      "main span",
      "main div",
    ];
    const nodes = new Set();
    selectors.forEach((selector) => {
      document.querySelectorAll(selector).forEach((node) => {
        if (node instanceof HTMLElement) nodes.add(node);
      });
    });

    for (const node of nodes) {
      const rect = node.getBoundingClientRect();
      if (rect.width < 60 || rect.height < 8) continue;
      if (rect.height > 180 || rect.top < 60) continue;
      const rawPieces = [
        node.getAttribute("data-pre-plain-text"),
        node.getAttribute("title"),
        node.getAttribute("aria-label"),
        node.innerText || node.textContent || "",
      ].filter(Boolean);
      const pieces = rawPieces.flatMap((piece) => {
        const lines = String(piece)
          .split(/\n+/)
          .map(cleanText)
          .filter(Boolean);
        return [cleanText(piece)].concat(lines);
      }).filter(Boolean);
      for (const piece of pieces) {
        if (piece.length > 280) continue;
        const phones = extractPhones(piece);
        if (!phones.length) continue;
        for (const phone of phones) {
          const name = nameFromPhoneLine(piece, phone);
          if (!name) continue;
          const key = `${phone}|${name}`;
          if (seen.has(key)) continue;
          seen.add(key);
          records.push({
            "姓名": name,
            "手機": phone,
            "公司": "",
            "職稱": "",
            "備註": "聊天訊息可見姓名電話",
            "群組 / 標籤": "WhatsApp",
            "來源": "聊天訊息",
            "電話狀態": "已抓到電話",
            "最後互動": "",
            "最後訊息摘要": "",
          });
        }
      }
    }
    return records;
  }

  function rowKey(record) {
    return record["手機"] || record["姓名"].toLowerCase();
  }

  function state() {
    if (!window[STATE_KEY]) {
      window[STATE_KEY] = {
        records: new Map(),
        scanning: false,
        enriching: false,
        running: false,
        internalIndex: null,
        internalIndexAt: 0,
      };
    }
    return window[STATE_KEY];
  }

  function mergeRecord(base, incoming) {
    const merged = Object.assign({}, base || {}, incoming || {});
    const nameCandidates = [base && base["姓名"], incoming && incoming["姓名"]]
      .map(cleanText)
      .filter(Boolean)
      .filter((name) => !extractPhones(name).length);
    const [leftName, rightName] = nameCandidates;
    if (leftName && rightName && leftName !== rightName) {
      if (leftName.includes(rightName)) merged["姓名"] = rightName;
      else if (rightName.includes(leftName)) merged["姓名"] = leftName;
      else merged["姓名"] = leftName.length <= rightName.length ? leftName : rightName;
    } else {
      merged["姓名"] = leftName || rightName || (base && base["姓名"]) || (incoming && incoming["姓名"]) || "";
    }
    merged["手機"] = (incoming && incoming["手機"]) || (base && base["手機"]) || "";
    merged["備註"] = Array.from(
      new Set(
        [base && base["備註"], incoming && incoming["備註"]]
          .filter(Boolean)
          .join("；")
          .split("；")
          .map(cleanText)
          .filter(Boolean)
      )
    ).join("；");
    const statusRank = ["缺電話", "已抓到電話", "已由內部狀態配對", "已補到電話"];
    const statuses = [base && base["電話狀態"], incoming && incoming["電話狀態"]].filter(Boolean);
    merged["電話狀態"] = merged["手機"]
      ? statuses.sort((a, b) => statusRank.indexOf(b) - statusRank.indexOf(a))[0] || "已抓到電話"
      : "缺電話";
    return merged;
  }

  function upsertRecord(record) {
    if (isKnownSavedContact(record)) return false;
    const appState = state();
    const phoneKey = record["手機"];
    const nameKey = record["姓名"] ? record["姓名"].toLowerCase() : "";
    const currentKey = phoneKey || nameKey;
    if (!currentKey) return false;

    const existingByPhone = phoneKey && appState.records.get(phoneKey);
    const existingByName = nameKey && appState.records.get(nameKey);
    if (!phoneKey && nameKey && !existingByName) {
      const nameMatches = Array.from(appState.records.entries()).filter(([, existingRecord]) =>
        existingRecord && existingRecord["手機"] && namesProbablyMatch(record["姓名"], existingRecord["姓名"])
      );
      if (nameMatches.length === 1) {
        const [matchedKey, matchedRecord] = nameMatches[0];
        appState.records.set(matchedKey, mergeRecord(matchedRecord, record));
        return false;
      }
    }
    const existing = existingByPhone || existingByName;
    const finalKey = phoneKey || nameKey;
    const merged = mergeRecord(existing, record);

    if (existingByName && phoneKey && nameKey !== phoneKey) {
      appState.records.delete(nameKey);
    }
    appState.records.set(finalKey, merged);
    return !existing;
  }

  function scanVisible() {
    const appState = state();
    let added = 0;
    for (const row of findRows()) {
      const record = recordFromRow(row);
      if (!record) continue;
      if (upsertRecord(record)) added += 1;
    }
    for (const record of messageContactRecords()) {
      if (upsertRecord(record)) added += 1;
    }
    render();
    setStatus(`本次新增 ${added} 筆，目前共 ${appState.records.size} 筆。`);
    return added;
  }

  function findBestScroller() {
    const candidates = Array.from(document.querySelectorAll("div, main, section"))
      .filter((node) => node instanceof HTMLElement)
      .map((node) => ({
        node,
        score:
          (node.scrollHeight - node.clientHeight) +
          node.querySelectorAll("[role='listitem'], [role='row']").length * 90,
      }))
      .filter((item) => item.node.scrollHeight > item.node.clientHeight + 80)
      .sort((a, b) => b.score - a.score);
    return candidates[0] ? candidates[0].node : document.scrollingElement;
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  async function autoScrollScan(options) {
    const config = options && !options.target ? options : {};
    const maxScrolls = Number(config.maxScrolls || 30);
    const stableLimit = Number(config.stableLimit || 6);
    const appState = state();
    if (isTrialExpired()) {
      setStatus(trialMessage(), true);
      return;
    }
    if (appState.scanning) return;
    appState.scanning = true;
    render();
    const scroller = findBestScroller();
    let stable = 0;
    let previousCount = appState.records.size;
    for (let i = 0; i < maxScrolls; i += 1) {
      scanVisible();
      scroller.scrollTop += Math.max(360, scroller.clientHeight * 0.78);
      await sleep(420);
      const currentCount = appState.records.size;
      if (currentCount === previousCount) stable += 1;
      else stable = 0;
      previousCount = currentCount;
      setStatus(`自動掃描中：第 ${i + 1}/${maxScrolls} 次捲動，目前 ${currentCount} 筆。`);
      if (stable >= stableLimit) break;
    }
    appState.scanning = false;
    render();
    setStatus(`掃描完成，目前共 ${appState.records.size} 筆。需要更多電話時，再按「補電話」。`);
  }

  function visibleTextFromSelectors(selectors) {
    return selectors
      .flatMap((selector) => Array.from(document.querySelectorAll(selector)))
      .filter((node) => node instanceof HTMLElement)
      .filter((node) => {
        const rect = node.getBoundingClientRect();
        return rect.width > 40 && rect.height > 12;
      })
      .map((node) => cleanText(`${node.getAttribute("title") || ""} ${node.getAttribute("aria-label") || ""} ${node.innerText || ""}`))
      .join(" ");
  }

  function currentDetailPhones() {
    const focusedText = visibleTextFromSelectors([
      "aside",
      "[role='complementary']",
      "[data-testid*='drawer']",
      "[data-testid*='contact']",
      "[data-testid*='conversation-info']",
      "header",
    ]);
    return extractPhones(focusedText);
  }

  function pairExistingFromInternalState() {
    let updated = 0;
    const appState = state();
    Array.from(appState.records.values()).forEach((record) => {
      if (record["手機"]) return;
      const before = record["手機"];
      enrichRecordFromInternalState(record);
      if (!before && record["手機"]) {
        upsertRecord(record);
        updated += 1;
      }
    });
    return updated;
  }

  function clickableChatHeader(name) {
    const candidates = Array.from(document.querySelectorAll("header [role='button'], header, [data-testid*='conversation-info-header'], [data-testid*='chat-info']"))
      .filter((node) => node instanceof HTMLElement)
      .filter((node) => {
        const rect = node.getBoundingClientRect();
        return rect.width > 120 && rect.height > 24 && rect.top < window.innerHeight * 0.35;
      });
    if (name) {
      const found = candidates.find((node) => cleanText(node.innerText || node.getAttribute("title") || "").includes(name));
      if (found) return found;
    }
    return candidates[0] || null;
  }

  async function enrichVisiblePhones() {
    const appState = state();
    if (isTrialExpired()) {
      setStatus(trialMessage(), true);
      return;
    }
    if (appState.enriching) return;
    appState.enriching = true;
    render();
    const pairedFromState = pairExistingFromInternalState();
    if (pairedFromState) {
      render();
      setStatus(`已先用 WhatsApp Web 內部聯絡人狀態配對 ${pairedFromState} 筆電話，接著檢查仍缺電話的聊天資訊頁。`);
      await sleep(350);
    }
    const rows = findRows().slice(0, 20);
    let updated = 0;
    let checked = 0;

    for (const row of rows) {
      const initial = recordFromRow(row);
      if (!initial || initial["手機"]) continue;
      checked += 1;
      setStatus(`補電話中：正在打開第 ${checked} 筆「${initial["姓名"] || "未命名"}」...`);
      row.dispatchEvent(new MouseEvent("mousedown", { bubbles: true }));
      row.click();
      await sleep(650);
      for (const record of messageContactRecords()) {
        if (upsertRecord(record)) updated += 1;
      }

      let phones = currentDetailPhones();
      if (!phones.length) {
        const header = clickableChatHeader(initial["姓名"]);
        if (header) {
          header.click();
          await sleep(850);
          phones = currentDetailPhones();
          document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
        }
      }

      if (phones.length) {
        initial["手機"] = phones[0];
        initial["電話狀態"] = "已補到電話";
        initial["備註"] = [initial["備註"], DETAIL_PAIR_NOTE].filter(Boolean).join("；");
        upsertRecord(initial);
        updated += 1;
      } else {
        initial["電話狀態"] = "缺電話";
        upsertRecord(initial);
      }
      render();
      await sleep(250);
    }

    appState.enriching = false;
    render();
    setStatus(`補電話完成：內部狀態配對 ${pairedFromState} 筆，逐筆資訊頁檢查 ${checked} 筆、補到 ${updated} 筆。若仍缺電話，代表 WhatsApp Web 目前頁面與已載入狀態沒有露出電話。`);
  }

  async function oneClickCapture() {
    const appState = state();
    if (isTrialExpired()) {
      render();
      setStatus(trialMessage(), true);
      return;
    }
    if (appState.running || appState.scanning || appState.enriching) return;
    appState.running = true;
    let finalMessage = "";
    let finalError = false;
    render();
    setStatus("一鍵抓名單中：先讀 WhatsApp Web 已載入的內部聯絡人/聊天狀態，再補掃目前畫面...");
    try {
      const bulk = await bulkCaptureInternalContacts();
      if (bulk.total) {
        render();
        setStatus(`已先從內部狀態整理 ${bulk.total} 筆、其中新增 ${bulk.added} 筆，接著補掃目前畫面。`);
        await sleep(120);
      }
      scanVisible();
      await autoScrollScan({ maxScrolls: 12, stableLimit: 4 });
      const pairedFromState = pairExistingFromInternalState();
      if (pairedFromState) render();
      const total = appState.records.size;
      const withPhone = Array.from(appState.records.values()).filter((record) => record["手機"]).length;
      finalMessage = `抓名單完成：共 ${total} 筆，其中 ${withPhone} 筆已有電話。已自動排除 WhatsApp 標記為手機通訊錄已有的聯絡人；確認後按「下載 CSV」。`;
    } catch (error) {
      finalMessage = `抓名單失敗：${error.message || error}`;
      finalError = true;
    } finally {
      appState.running = false;
      render();
      if (finalMessage) setStatus(finalMessage, finalError);
    }
  }

  function csvEscape(value) {
    const text = String(value == null ? "" : value);
    return /[",\r\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
  }

  function toCsv() {
    const headers = ["姓名", "手機", "公司", "職稱", "備註", "群組 / 標籤"];
    const rows = Array.from(state().records.values()).filter((record) => record["手機"]);
    return [headers.join(",")]
      .concat(rows.map((record) => headers.map((header) => csvEscape(record[header])).join(",")))
      .join("\r\n");
  }

  function downloadCsv() {
    if (isTrialExpired()) {
      render();
      setStatus(trialMessage(), true);
      return;
    }
    scanVisible();
    if (!state().records.size) {
      setStatus("目前沒有可匯出的資料。請先打開聊天列表、聯絡人列表或群組成員頁。", true);
      return;
    }
    const exportCount = Array.from(state().records.values()).filter((record) => record["手機"]).length;
    if (!exportCount) {
      setStatus("目前沒有可匯出的手機號碼。請先進入有電話的聯絡人列表或群組成員頁。", true);
      return;
    }
    const blob = new Blob(["\uFEFF", toCsv()], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    const stamp = new Date().toISOString().slice(0, 10);
    link.href = url;
    link.download = `成交聯盟_WhatsApp抓名單_${stamp}.csv`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    setStatus(`已下載 CSV：${exportCount} 筆有手機號碼的資料。`);
  }

  async function copyCsv() {
    if (isTrialExpired()) {
      render();
      setStatus(trialMessage(), true);
      return;
    }
    scanVisible();
    try {
      await navigator.clipboard.writeText(toCsv());
      const exportCount = Array.from(state().records.values()).filter((record) => record["手機"]).length;
      setStatus(`已複製 CSV：${exportCount} 筆有手機號碼的資料。`);
    } catch (error) {
      setStatus(`複製失敗，請改用下載 CSV。${error.message}`, true);
    }
  }

  function setStatus(message, isError) {
    const panel = document.getElementById(APP_ID);
    const status = panel && panel.querySelector("[data-da-status]");
    if (!status) return;
    status.textContent = message;
    status.style.color = isError ? "#b42318" : "#3b4a5f";
  }

  function clearRecords() {
    state().records.clear();
    render();
    setStatus("已清空本次掃描資料。");
  }

  function render() {
    let panel = document.getElementById(APP_ID);
    if (!panel) {
      panel = document.createElement("aside");
      panel.id = APP_ID;
      document.body.appendChild(panel);
    }
    const count = state().records.size;
    const withPhone = Array.from(state().records.values()).filter((record) => record["手機"]).length;
    const trial = trialInfo();
    panel.textContent = "";

    const make = (tag, attrs, text) => {
      const node = document.createElement(tag);
      Object.entries(attrs || {}).forEach(([key, value]) => {
        if (key === "class") node.className = value;
        else if (key === "dataset") Object.assign(node.dataset, value);
        else if (key === "disabled" && value) node.disabled = true;
        else if (key !== "disabled") node.setAttribute(key, value);
      });
      if (text != null) node.textContent = text;
      return node;
    };

    const style = make("style");
    style.textContent = `
      #${APP_ID}{position:fixed;z-index:2147483647;right:20px;top:76px;width:342px;max-width:calc(100vw - 32px);max-height:calc(100vh - 96px);display:flex;flex-direction:column;font-family:-apple-system,BlinkMacSystemFont,"PingFang TC","Microsoft JhengHei",sans-serif;color:#10233f;background:#fff;border:1px solid #d9e1ec;border-radius:18px;box-shadow:0 24px 70px rgba(16,35,63,.22);overflow:hidden}
      #${APP_ID} .da-head{padding:16px 16px 12px;background:#10233f;color:#fff}
      #${APP_ID} .da-eyebrow{font-size:12px;color:rgba(255,255,255,.7);font-weight:700;margin-bottom:4px}
      #${APP_ID} h2{font-size:18px;line-height:1.25;margin:0}
      #${APP_ID} .da-body{padding:14px 16px 16px;overflow-y:auto}
      #${APP_ID} .da-count{display:flex;align-items:end;gap:8px;margin-bottom:10px}
      #${APP_ID} .da-count strong{font-size:34px;line-height:1}
      #${APP_ID} .da-count span{color:#6c7a8c;font-size:13px;font-weight:650}
      #${APP_ID} .da-mini{margin:-4px 0 10px;color:#6c7a8c;font-size:12px;font-weight:650}
      #${APP_ID} .da-trial{margin:0 0 10px;padding:8px 10px;border-radius:10px;background:${trial.expired ? "#fff0ed" : "#f1fbf5"};color:${trial.expired ? "#b42318" : "#217346"};font-size:12px;font-weight:750;line-height:1.45}
      #${APP_ID} .da-actions{display:grid;grid-template-columns:1fr 1fr;gap:8px}
      #${APP_ID} button{border:0;border-radius:10px;min-height:40px;padding:0 10px;font:inherit;font-weight:750;cursor:pointer}
      #${APP_ID} button:disabled{opacity:.46;cursor:not-allowed}
      #${APP_ID} .primary{grid-column:1/-1;background:#0a84ff;color:#fff;min-height:46px}
      #${APP_ID} .secondary{background:#edf3fb;color:#10233f}
      #${APP_ID} .emphasis{grid-column:1/-1;background:#e7f2ff;color:#07539b;min-height:44px}
      #${APP_ID} .danger{background:#fff0ed;color:#b42318}
      #${APP_ID} [data-da-status]{min-height:38px;margin-top:10px;padding:9px 10px;border-radius:10px;background:#f7f9fc;font-size:13px;line-height:1.45}
      #${APP_ID} details{margin-top:8px}
      #${APP_ID} summary{cursor:pointer;color:#6c7a8c;font-size:12px;font-weight:750;list-style:none}
      #${APP_ID} summary::-webkit-details-marker{display:none}
      #${APP_ID} .da-advanced{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px}
    `;
    panel.appendChild(style);

    const head = make("div", { class: "da-head" });
    head.appendChild(make("div", { class: "da-eyebrow" }, "成交聯盟 WhatsApp 抓名單"));
    head.appendChild(make("h2", null, "一鍵整理 WhatsApp 名單"));
    panel.appendChild(head);

    const body = make("div", { class: "da-body" });
    const countWrap = make("div", { class: "da-count" });
    countWrap.appendChild(make("strong", null, String(count)));
    countWrap.appendChild(make("span", null, "筆已整理資料"));
    body.appendChild(countWrap);
    body.appendChild(make("div", { class: "da-trial" }, trialMessage()));
    body.appendChild(make("div", { class: "da-mini" }, `其中 ${withPhone} 筆已有電話。已在手機通訊錄的聯絡人會自動排除。`));

    const actions = make("div", { class: "da-actions" });
    const busy = state().running || state().scanning || state().enriching;
    actions.appendChild(make("button", { class: "primary", dataset: { daRun: "" }, disabled: trial.expired }, busy ? "處理中..." : "一鍵抓名單"));
    actions.appendChild(make("button", { class: "emphasis", dataset: { daEnrich: "" }, disabled: trial.expired }, state().enriching ? "補電話中..." : "補電話"));
    actions.appendChild(make("button", { class: "primary", dataset: { daDownload: "" }, disabled: trial.expired }, "下載 CSV"));
    actions.appendChild(make("button", { class: "secondary", dataset: { daCopy: "" }, disabled: trial.expired }, "複製 CSV"));
    actions.appendChild(make("button", { class: "secondary", dataset: { daClose: "" } }, "關閉"));
    actions.appendChild(make("button", { class: "danger", dataset: { daClear: "" } }, "清空"));
    body.appendChild(actions);

    const details = make("details");
    details.appendChild(make("summary", null, "進階工具"));
    const advanced = make("div", { class: "da-advanced" });
    advanced.appendChild(make("button", { class: "secondary", dataset: { daScan: "" }, disabled: trial.expired }, "只掃目前畫面"));
    advanced.appendChild(make("button", { class: "secondary", dataset: { daAuto: "" }, disabled: trial.expired }, state().scanning ? "掃描中..." : "只自動捲動"));
    details.appendChild(advanced);
    body.appendChild(details);
    body.appendChild(make("div", { dataset: { daStatus: "" } }, "請打開聊天列表、聯絡人列表或群組成員頁，按「一鍵抓名單」。"));
    panel.appendChild(body);

    panel.querySelector("[data-da-run]").onclick = oneClickCapture;
    panel.querySelector("[data-da-scan]").onclick = scanVisible;
    panel.querySelector("[data-da-auto]").onclick = autoScrollScan;
    panel.querySelector("[data-da-enrich]").onclick = enrichVisiblePhones;
    panel.querySelector("[data-da-download]").onclick = downloadCsv;
    panel.querySelector("[data-da-copy]").onclick = copyCsv;
    panel.querySelector("[data-da-clear]").onclick = clearRecords;
    panel.querySelector("[data-da-close]").onclick = () => panel.remove();
  }

  render();
  if (isTrialExpired()) {
    setStatus(trialMessage(), true);
  } else {
    setStatus("面板已開啟。按「一鍵抓名單」會排除已在手機通訊錄的聯絡人，再整理可匯入 CSV。");
  }
})();
