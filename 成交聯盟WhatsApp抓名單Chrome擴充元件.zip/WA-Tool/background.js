chrome.action.onClicked.addListener(async (tab) => {
  if (!tab || !tab.id) return;
  if (!tab.url || !tab.url.startsWith('https://web.whatsapp.com/')) {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => alert('請先打開 WhatsApp Web，再點成交聯盟抓名單工具。')
    });
    return;
  }
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['content.js'],
      world: 'MAIN'
    });
  } catch (mainWorldError) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['content.js']
      });
    } catch (fallbackError) {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: (message) => alert(`成交聯盟抓名單工具啟動失敗，請重新整理 WhatsApp Web 後再點一次。錯誤：${message}`),
        args: [fallbackError && fallbackError.message ? fallbackError.message : String(fallbackError)]
      });
    }
  }
});
