chrome.action.onClicked.addListener(async (tab) => {
  if (!tab || !tab.id) return;
  if (!tab.url || !tab.url.startsWith('https://web.whatsapp.com/')) {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => alert('請先打開 WhatsApp Web，再點成交聯盟抓名單工具。')
    });
    return;
  }
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    files: ['content.js'],
    world: 'MAIN'
  });
});
